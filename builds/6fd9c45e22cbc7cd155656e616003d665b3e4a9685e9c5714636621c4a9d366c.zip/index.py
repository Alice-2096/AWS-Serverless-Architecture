import boto3

dynamodb = boto3.resource('dynamodb', region_name='us-east-1')

    
def lambda_handler(event, context):
    table = dynamodb.Table('my-table')
    table.put_item(Item={
            'id': '1',
            'email': 'myemail@yahoo.com'
        })

    return { 
        'statusCode': 200,
        'headers': {'Content-Type': 'application/json'}
    }