import boto3
import uuid

dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
table = dynamodb.Table('my-table')
    
def lambda_handler(event, context):
    new_id = uuid.uuid4().int
    if 'body' not in event:
        return { 
            'statusCode': 400,
            'headers': {'Content-Type': 'application/json'}
        }
    if 'email' not in event['body']:
        return { 
            'statusCode': 400,
            'headers': {'Content-Type': 'application/json'}
        }
    email_ = event['body']['email']
    table.put_item(Item={
            'id': new_id,
            'email': email_
        })

    return { 
        'statusCode': 200,
        'headers': {'Content-Type': 'application/json'}
    }